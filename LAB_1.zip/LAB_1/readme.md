Булавчук Данило Юрійович , група КВ-23
Лабораторна робота № 1
Розробка статичного інтерфейсу Web-додатка
https://drive.google.com/drive/folders/1a9ULWhNpy7IoWyZEBBczfb1XqZd353Yw?usp=sharing